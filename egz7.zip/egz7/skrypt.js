function oblicz() {
    
    let wynik = document.getElementById("wynik");

    let cena = 0;

    const Peeling = document.getElementById('Peeling');

    const Maska = document.getElementById('Maska');

    const Masaz = document.getElementById('Masaz');

    const Makijaz = document.getElementById('Makijaz');

    if(Peeling.checked) {
        cena = cena + 45;
    }
    if(Maska.checked) {
        cena = cena + 30;
    }
    if(Masaz.checked) {
        cena = cena + 20;
    }
    if(Makijaz.checked) {
        cena = cena + 50;
    }

    wynik.innerHTML = "<p>Cena zabiegów: " + cena + "</p>";
}