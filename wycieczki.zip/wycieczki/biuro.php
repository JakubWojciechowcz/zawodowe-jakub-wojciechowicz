<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Poznaj Europę</title>
    <link rel="stylesheet" href="styl9.css">
</head>
<body>
    <header>
        <h1>BIURO PODRÓŻY</h1>
    </header>

    <aside id="lewy">
        <h2>Promocje</h2>
        <table>
            <tr>
            <td>Warszawa</td>
            <td>od 600zł</td>
        </tr>
        <tr>
            <td>Wenecja</td>
            <td>od 1200zł</td>
        </tr>
        <tr>
            <td>Paryż</td>
            <td>od 1200zł</td>
        </tr>
        </table>
    </aside>

    <main>
        <h2>W tym roku jedziemy do...</h2>
        <?php
$polaczenie=mysqli_connect('localhost','root','','podroze');
$zapytanie="SELECT nazwaPliku, podpis FROM `zdjecia` ORDER BY podpis;";
$wynik=mysqli_query($polaczenie,$zapytanie);
while($tab=mysqli_fetch_row($wynik)){
    echo "<img src=$tab[0] alt=$tab[1] title=$tab[1]>";
}

        ?>
    </main>

    <aside id="prawy">
        <h2>Kontakt</h2>
        <a href="biuro@wycieczki.pl">napisz do nas</a>
        <p>telefon: 444555666</p>
    </aside>

    <section id="dane">
        <h3>W poprzednih latach byliśmy:</h3>
        <ol>
            
                <?php
            $polaczenie=mysqli_connect('localhost','root','','podroze');
            $zapytanie2="SELECT cel, dataWyjazdu FROM `wycieczki` WHERE dostepna = 0;";
            $wynik2=mysqli_query($polaczenie,$zapytanie2);
            while($tab=mysqli_fetch_row($wynik2)){
                echo "<li>Dnia $tab[1] pojechaliśmy do $tab[0]</li>";
            }
                mysqli_close($polaczenie);
                ?>

            
        </ol>
    </section>

    <footer><p>Stronę wykonał: Jakub Wojciechowicz</p></footer>
    
</body>
</html>