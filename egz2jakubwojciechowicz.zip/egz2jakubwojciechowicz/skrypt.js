let teksty = [
    "Świetnie!",
"Kto gra główną rolę?",
"Lubisz filmy Tego reżysera?",
"Będę 10 minut wcześniej",
"Może kupimy sobie popcorn?",
"Ja wolę Colę",
"Zaproszę jeszcze Grześka",
"Tydzień temu też byłem w kinie na Diunie",
"Ja funduję bilety"
];


function wyslij(){
    let messageInput = document.getElementById('wiadomosc');
    let chat = document.getElementById('chat');

    let jolkaSection = document.createElement('section');
    jolkaSection.classList.add('jolka');

    let jolkaImg = document.createElement('img');
    jolkaImg.src = 'Jolka.jpg';
    jolkaImg.alt = 'Jolanta Nowak';

    let jolkaP = document.createElement('p');
    jolkaP.textContent = messageInput.value;

    jolkaSection.appendChild(jolkaImg);
    jolkaSection.appendChild(jolkaP);
    chat.appendChild(jolkaSection);

    chat.scrollTop = chat.scrollHeight;
    messageInput.value = '';
}

function generuj(){
    let randomIndex = Math.floor(Math.random() * teksty.length);
    let randomResponse = teksty[randomIndex];


    let chat = document.getElementById('chat');
    let krzysiekSection = document.createElement('section');
    krzysiekSection.classList.add('krzysiek');


    let krzysiekImg = document.createElement('img');
    krzysiekImg.src = 'Krzysiek.jpg';
    krzysiekImg.alt = 'Krzysztof Łukasiński';


    let krzysiekP = document.createElement('p');
    krzysiekP.textContent = randomResponse;
    krzysiekSection.appendChild(krzysiekImg);
    krzysiekSection.appendChild(krzysiekP);

    chat.appendChild(krzysiekSection);
    chat.scrollTop = chat.scrollHeight;

}

