<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rozgrywki futbolowe</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <div class="baner">
        <h2>Światowe rozgrywki piłkarskie</h2>
        <img src="obraz1.jpg" alt="boisko">
    </div>
    <div class="mecze">
        <?php
        $serwer = 'localhost';
        $uzytkownik = 'root';
        $dbname = 'egzamin';
        $password = '';

        $db = mysqli_connect($serwer, $uzytkownik, $password, $dbname);

        $q = 'SELECT zespol1, zespol2, wynik, data_rozgrywki FROM `rozgrywka` WHERE zespol1 = "EVG";';

        $result = mysqli_query($db, $q);

        while($row = mysqli_fetch_array($result)){
           echo '<div class="info">
            <h3>'.$row["zespol1"].' - '.$row["zespol2"].'</h3>
            <h4>'.$row["wynik"].'</h4>
            <p>w dniu: '.$row["data_rozgrywki"].'</p>
            </div>';
        }
        ?>

        </div>

  
    
    <div class="glowny">
        <h2>Reprezentacja Polski</h2>
    </div>
    <div class="lewy">
        <p>
            „Podaj pozycję zawodników (1-bramkarze, 2-obrońcy, 3-pomocnicy, 4-
            napastnicy): 
        </p>
        <form action="futbol.php" method="post">
            <input type="number" name="numer" name="zawodnik" id="zawodnik">
            <button type="submit" name="formularz">Sprawdź</button>

        </form>
        <ul>
                  <?php
        if(isset($_POST["formularz"])){
            $numer = $_POST["numer"];
            if($numer!=""){

                $q = 'SELECT imie, nazwisko FROM `zawodnik` WHERE pozycja_id = "'.$numer.'";';

                $result = mysqli_query($db, $q);

                while($row = mysqli_fetch_array($result)){
                    echo '<li><p>'.$row["imie"].''.$row["nazwisko"].'</p></li>';
                } 
            }
        }
        mysqli_close($db)


        ?>
        </ul>
  


    </div>
    <div class="prawy">
        <img src="zad1.png" alt="pilkarz">
        <p>Autor:Jakub Wojciechowicz</p>
    </div>
    
</body>
</html>