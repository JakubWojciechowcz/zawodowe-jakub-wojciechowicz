<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Motocykle</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
   <div class="motor">
    <img src="motor.png" alt="motocykl">
    </div>
   
    <div class="baner">
        <h1>Motocykle - moja pasja</h1>
    </div>
    <div class="lewy">
        <h2>Gdzie pojechać?</h2>
        <?php
        $db = mysqli_connect("localhost", "root", "", "motor");

        $sql = "SELECT nazwa, opis, poczatek, zrodlo FROM `wycieczki` JOIN zdjecia on zdjecia.id = zdjecia_id;";
        $result = $db->query($sql);

       
        
            while($row = $result->fetch_array()) {
             echo "<div class = 'terminy'>";
             echo "$row[0], rozpoczyna się w $row[2], <a href='$row[3].jpg'>zobacz zdjęcia</a>";
             echo "</div>";
             echo "<div class = 'opis'>";
             echo $row[1];
             echo "</div>";
        
             } 
            
           
                
        ?>
    </div>
    <div class="prawy1">
        <h2>Co kupić?</h2>
        <ol>
            <li>Honda CBR125R</li>
            <li>Yamaha YBR125</li>
            <li>Honda VFR800i</li>
            <li>Honda CBR1100XX</li>
            <li>BMW R1200GS LC</li>

        </ol>
    </div>
    <div class="prawy2">
        <h2>Statystyki</h2>
        <?php
        $sql = "SELECT COUNT(*) FROM `wycieczki`;";
        $result = $db->query($sql);
        while($row = $result->fetch_array()) {
            $liczba = $row[0];
        }
        echo "<p>Wpisanych wycieczek: $liczba </p>";
        $db -> close();
        ?>
        
        <p>Użytkowników forum: 200</p>
        <p>Przesłanych zdjęć: 1300</p>
    </div>
    <div class="stopka">
        <p>Stronę wykonał: Jakub Wojciechowicz</p>
    </div>
</body>
</html>